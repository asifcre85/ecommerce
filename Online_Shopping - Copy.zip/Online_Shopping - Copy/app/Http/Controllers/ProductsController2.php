<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use Illuminate\Support\Facades\Input;
use Auth;
use Session;
use Image;
use App\Category;
use App\Product;
use App\ProductsAttribute;
use App\ProductsImage;
use App\Coupon;
use DB;
use App\User;
use App\Country;
use App\Order;
use App\OrdersProduct;
use App\DeliveryAddress;

class ProductsController2 extends Controller
{
    public function addProduct(Request $request){
        //this code save product records in database
         if($request->isMethod('post')){
             $data = $request->all();
             //echo "<pre>"; print_r($data); die;
             if(empty($data['category_id'])){
             return redirect()->back()->with('flash_message_error','Under Category is Missing :(');    
             }
             $product = new Product;
             $product->category_id .= $data['category_id'];
             $product->product_name= $data['product_name'];
             $product->product_code = $data['product_code'];
             $product->product_color = $data['product_color'];
             
             if(!empty($data['description'])){
             $product->description = $data['description'];
             }else{
             $product->description = '';
             }
             if(!empty($data['care'])){
                 $product->care = $data['care'];
                 }else{
                 $product->care = '';
                 }
 
             $product->price = $data['price'];
             //upload image code
             if($request->hasfile('image')){
                 echo $image_tmp = Input::file('image');
                 if($image_tmp->isValid()){
                 //Image File Pat code
                 $extension = $image_tmp->getClientOriginalExtension();
                 $filename = rand(111,99999).'.'.$extension;
                 $large_image_path = 'images/backend_img/products/large/'.$filename;
                 $small_image_path = 'images/backend_img/products/small/'.$filename;
                 $medium_image_path = 'images/backend_img/products/medium/'.$filename;
                 //image resize code
                 Image::make($image_tmp)->save($large_image_path);
                 Image::make($image_tmp)->resize(300,300)->save($small_image_path);
                 Image::make($image_tmp)->resize(600,600)->save($medium_image_path);
                 //Store img name in products table
                 $product->image = $filename; 
                 }
             }
             $product->save();
             return redirect('view-products2')->with('flash_message_success','Product has been Added Successfully!!!'); 
         }
 
         //this code genrate categories in drop box menu in add products page
         //categories drop down starts
 
         $categories = Category::where(['Parent_id'=>0])->get();
         $categories_dropdown = "<option value='' selected disabled>Select</option>";
         foreach($categories as $cat){
             $categories_dropdown .= "<option value='".$cat->id."'>".$cat->Name."</option>";
         //code for showing subcategories in main category
         $sub_categories = Category::where(['Parent_id'=>$cat->id])->get();
         foreach($sub_categories as $sub_cat){
         $categories_dropdown .= "<option value = '".$sub_cat->id."'>&nbsp;--&nbsp;".$sub_cat->Name."</option>";
         }
     } //categories drop down end
 
         return view('admin.products.add_product2')->with(compact('categories_dropdown'));
       
     }

     public function viewProducts(Request $request){
        $products = Product::get();
        //$products = json_decode(json_encode('$products'));
        foreach($products as $key =>$val){
            $category_name = Category::where(['id'=>$val->category_id])->first();
            $products[$key]->category_name = $category_name->Name;
        }
        //echo "<pre>"; print_r($products);die;
        return view ('admin.products.view_products2')->with(compact('products'));

    }


    }